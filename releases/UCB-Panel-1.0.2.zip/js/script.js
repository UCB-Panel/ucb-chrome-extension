$(document).ready( function() {
    $('.trigger').not('.trigger_active').next('.toggle_container').hide();
    var trig = $(this);
    if ( ! trig.hasClass('trigger_active') ) {
        $('.icon_arrow').css("background-image", "url(images/arrow_down.gif)");
    }
});

document.addEventListener("DOMContentLoaded", function() {
    var anchors = document.querySelectorAll("button");
    for (var i = 0; i < anchors.length; i++) {
        anchors[i].addEventListener("click", function(event) {
            if (event.currentTarget.value == "%COLLAPSE%") {
                    var trig = $(this);
                    if ( trig.hasClass('trigger_active') ) {
                        $('.icon_arrow').css("background-image", "url(images/arrow_down.gif)");
                        trig.next('.toggle_container').slideToggle('slow');
                        trig.removeClass('trigger_active');
                    } else {
                        $('.trigger_active').next('.toggle_container').slideToggle('slow');
                        $('.trigger_active').removeClass('trigger_active');
                        $('.icon_arrow').css("background-image", "url(images/arrow_up.gif)");
                        trig.next('.toggle_container').slideToggle('slow');
                        trig.addClass('trigger_active');
                    }

            } else {
                LaunchURL(event.currentTarget.value);
                event.preventDefault();
            }
        });
    }

    function LaunchURL(oURL) {
        var launchType = localStorage["LS_LaunchType"];
            switch (launchType) {
                case "TN":
                    chrome.tabs.create({ url: oURL });
                    break;
                case "WN":
                    chrome.windows.create({ url: oURL });
                    break;
                default:
                    chrome.tabs.create({ url: oURL });
                    break;
            }
        }
});
